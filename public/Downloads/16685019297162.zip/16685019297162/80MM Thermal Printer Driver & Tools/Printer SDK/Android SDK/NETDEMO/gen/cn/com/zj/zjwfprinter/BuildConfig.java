/** Automatically generated file. DO NOT MODIFY */
package cn.com.zj.zjwfprinter;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}